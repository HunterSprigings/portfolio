-- MySQL dump 10.13  Distrib 8.0.30, for macos12 (x86_64)
--
-- Host: cp363-db.cfoq5srjjul5.us-east-2.rds.amazonaws.com    Database: herc_rentals
-- ------------------------------------------------------
-- Server version	5.7.38-log
SET FOREIGN_KEY_CHECKS=0;
--
-- Table structure for table `StoreLocation`
--
DROP TABLE IF EXISTS `StoreLocation`;
CREATE TABLE `StoreLocation` (
  `idStoreLocation` int(11) NOT NULL AUTO_INCREMENT,
  `store_name` varchar(45) NOT NULL,
  PRIMARY KEY (`idStoreLocation`),
  UNIQUE KEY `store_name_UNIQUE` (`store_name`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `StoreAddress`;
CREATE TABLE `StoreAddress` (
  `idStoreLocation` int(11) NOT NULL,
  `address` varchar(45) NOT NULL,
  PRIMARY KEY (`idStoreLocation`),
  FOREIGN KEY (`idStoreLocation`) REFERENCES `StoreLocation` (`idStoreLocation`) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `StoreEmail`;
CREATE TABLE `StoreEmail` (
  `idStoreLocation` int(11) NOT NULL,
  `email` varchar(45) NOT NULL,
  PRIMARY KEY (`idStoreLocation`),
  FOREIGN KEY (`idStoreLocation`) REFERENCES `StoreLocation` (`idStoreLocation`) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `StorePhone`;
CREATE TABLE `StorePhone` (
  `idStoreLocation` int(11) NOT NULL,
  `phone` varchar(12) NOT NULL,
  PRIMARY KEY (`idStoreLocation`),
  FOREIGN KEY (`idStoreLocation`) REFERENCES `StoreLocation` (`idStoreLocation`) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Table structure for table `Customers`
--
DROP TABLE IF EXISTS `Customer`;
CREATE TABLE `Customer` (
  `idCustomer` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  PRIMARY KEY (`idCustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `CustomerPhone`;
CREATE TABLE `CustomerPhone` (
	phone varchar(12) NOT NULL,
    Customer_idCustomer int(11) NOT NULL,
    PRIMARY KEY (phone),
    CONSTRAINT fk_CustomerPhone_idCustomer FOREIGN KEY (Customer_idCustomer) REFERENCES Customer(idCustomer) ON UPDATE CASCADE ON DELETE CASCADE
    );
    
DROP TABLE IF EXISTS `CustomerEmail`;
CREATE TABLE `CustomerEmail` (
	email varchar(45) NOT NULL,
    Customer_idCustomer int(11) NOT NULL,
    PRIMARY KEY (email),
    CONSTRAINT fk_idCustomer_idCustomer FOREIGN KEY (Customer_idCustomer) REFERENCES Customer(idCustomer) ON UPDATE CASCADE ON DELETE CASCADE
    );


--
-- Table structure for table `Employees`
--
DROP TABLE IF EXISTS `Employees`;
CREATE TABLE `Employees` (
  `idEmployees` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `position` varchar(45) NOT NULL,
  `salary` float NOT NULL,
  `StoreLocation_idStoreLocation` int(11) NOT NULL,
  PRIMARY KEY (`idEmployees`),
  CONSTRAINT `fk_Employees_StoreLocation1` FOREIGN KEY (`StoreLocation_idStoreLocation`) REFERENCES `StoreLocation` (`idStoreLocation`) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `EmployeesAddress`;
CREATE TABLE `EmployeesAddress` (
  `address` varchar(45) NOT NULL,
  `employees_idEmployees` int(11) NOT NULL,
  PRIMARY KEY (`address`),
  CONSTRAINT `fk_EmployeesAddress_Employees` FOREIGN KEY (`employees_idEmployees`) REFERENCES `Employees` (`idEmployees`) ON UPDATE CASCADE ON DELETE CASCADE
);

DROP TABLE IF EXISTS `EmployeesEmail`;
CREATE TABLE `EmployeesEmail` (
  `email` varchar(45) NOT NULL,
  `employees_idEmployees` int(11) NOT NULL,
  PRIMARY KEY (`email`),
  CONSTRAINT `fk_EmployeesEmail_Employees` FOREIGN KEY (`employees_idEmployees`) REFERENCES `Employees` (`idEmployees`) ON UPDATE CASCADE ON DELETE CASCADE
);

DROP TABLE IF EXISTS `EmployeesPhone`;
CREATE TABLE `EmployeesPhone` (
  `phone` varchar(12) NOT NULL,
  `employees_idEmployees` int(11) NOT NULL,
  PRIMARY KEY (`phone`),
  CONSTRAINT `fk_EmployeesPhone_Employees` FOREIGN KEY (`employees_idEmployees`) REFERENCES `Employees` (`idEmployees`) ON UPDATE CASCADE ON DELETE CASCADE
);

--
-- Table structure for table `Equipment`
--
DROP TABLE IF EXISTS `Equipment`;
CREATE TABLE `Equipment` (
  `idEquipment` int(11) NOT NULL AUTO_INCREMENT,
  `maiteneance` tinyint(1) NOT NULL,
  `availability` tinyint(1) NOT NULL,
  `manufacturer` varchar(45) DEFAULT NULL,
  `rental_cost` float NOT NULL,
  `description` varchar(45) DEFAULT NULL,
  `StoreLocation_idStoreLocation` int(11) NOT NULL,
  PRIMARY KEY (`idEquipment`),
  CONSTRAINT `fk_Equipment_StoreLocation` FOREIGN KEY (`StoreLocation_idStoreLocation`) REFERENCES `StoreLocation` (`idStoreLocation`) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS SerialNum;
CREATE TABLE SerialNum (
`serial_num` int(11) NOT NULL,
equipment_idequipment int(11) NOT NULL,
PRIMARY KEY (serial_num),
CONSTRAINT fk_Equipment_SerialNum Foreign Key (equipment_idequipment) REFERENCES Equipment(idEquipment)
);

--
-- Table structure for table `RentalAgreement`
--
DROP TABLE IF EXISTS `RentalAgreement`;
CREATE TABLE `RentalAgreement` (
  `idRentalAgreement` int(11) NOT NULL AUTO_INCREMENT,
  `price` float NOT NULL,
  `payment_type` varchar(45) NOT NULL,
  `insurance_cost` varchar(45) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `Customer_idCustomer` int(11) NOT NULL,
  `Equipment_idEquipment` int(11) NOT NULL,
  PRIMARY KEY (`idRentalAgreement`),
  CONSTRAINT `fk_RentalAgreement_Customer1` FOREIGN KEY (`Customer_idCustomer`) REFERENCES `Customer` (`idCustomer`) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `fk_Equipment_idEquipment1` FOREIGN KEY (`Equipment_idEquipment`) REFERENCES `Equipment` (`idEquipment`) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Table structure for table `CreatesRentalAgreement`
--
DROP TABLE IF EXISTS `CreatesRentalAgreement`;
CREATE TABLE `CreatesRentalAgreement` (
  `Customer_idCustomer` int(11) NOT NULL,
  `Employees_idEmployees` int(11) NOT NULL,
  PRIMARY KEY (`Customer_idCustomer`,`Employees_idEmployees`),
  CONSTRAINT `fk_Customer_has_Employees_Customer` FOREIGN KEY (`Customer_idCustomer`) REFERENCES `Customer` (`idCustomer`) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `fk_Customer_has_Employees_Employees` FOREIGN KEY (`Employees_idEmployees`) REFERENCES `Employees` (`idEmployees`) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


--
-- Table structure for table `Invoice`
--
DROP TABLE IF EXISTS `Invoice`;
CREATE TABLE `Invoice` (
  `idInvoice` int(11) NOT NULL AUTO_INCREMENT,
  `Customer_idCustomer` int(11) NOT NULL,
  `Employees_idEmployees` int(11) NOT NULL,
  `Equipment_idEquipment` int(11) NOT NULL,
  `StoreLocation_idStoreLocation` int(11) NOT NULL,
  PRIMARY KEY (`idInvoice`),
  CONSTRAINT `fk_Invoice_Employees1` FOREIGN KEY (`Employees_idEmployees`) REFERENCES `Employees` (`idEmployees`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_Invoice_Customer1` FOREIGN KEY (`Customer_idCustomer`) REFERENCES `Customer` (`idCustomer`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_Invoice_Equipment1` FOREIGN KEY (`Equipment_idEquipment`) REFERENCES `Equipment` (`idEquipment`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_StoreLocation_idStoreLocation` FOREIGN KEY (`StoreLocation_idStoreLocation`) REFERENCES `StoreLocation` (`idStoreLocation` )ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS InvoiceRental;
CREATE TABLE InvoiceRental (
	RentalAgreement_idRentalAgreement int(11) NOT NULL,
    Invoice_idInvoice int(11) NOT NULL,
    PRIMARY KEY (RentalAgreement_idRentalAgreement, Invoice_idInvoice),
	CONSTRAINT `fk_Invoice_RentalAgreement` FOREIGN KEY (`RentalAgreement_idRentalAgreement`) REFERENCES `RentalAgreement` (`idRentalAgreement`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_RentalAgreement_Invoice` FOREIGN KEY (`Invoice_idInvoice`) REFERENCES `Invoice` (`idInvoice`) ON DELETE CASCADE ON UPDATE CASCADE
);

--
-- Table structure for table `Maintains`
--
DROP TABLE IF EXISTS `Maintains`;
CREATE TABLE `Maintains` (
  `Equipment_idEquipment` int(11) NOT NULL,
  `Employees_idEmployees` int(11) NOT NULL,
  PRIMARY KEY (`Equipment_idEquipment`,`Employees_idEmployees`),
  CONSTRAINT `fk_Employees_has_Equipment_Employees1` FOREIGN KEY (`Employees_idEmployees`) REFERENCES `Employees` (`idEmployees`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_Equipment_has_Employees_Equipment1` FOREIGN KEY (`Equipment_idEquipment`) REFERENCES `Equipment` (`idEquipment`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


--
-- Table structure for table `Rents`
--
DROP TABLE IF EXISTS `Rents`;
CREATE TABLE `Rents` (
  `RentalAgreement_idRentalAgreement` int(11) NOT NULL,
  `Customer_idCustomer` int(11) NOT NULL,
  PRIMARY KEY (`RentalAgreement_idRentalAgreement`,`Customer_idCustomer`),
  CONSTRAINT `fk_RentalAgreement_has_Customer_Customer1` FOREIGN KEY (`Customer_idCustomer`) REFERENCES `Customer` (`idCustomer`) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `fk_RentalAgreement_has_Customer_Equipment` FOREIGN KEY (`RentalAgreement_idRentalAgreement`) REFERENCES `RentalAgreement` (`idRentalAgreement`) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Table structure for table `ProvidesInvoice`
--
DROP TABLE IF EXISTS `ProvidesInvoice`;
CREATE TABLE `ProvidesInvoice` (
  `Customer_idCustomer` int(11) NOT NULL,
  `Employees_idEmployees` int(11) NOT NULL,
  PRIMARY KEY (`Customer_idCustomer`,`Employees_idEmployees`),
  CONSTRAINT `fk_Customer_has_Employees_Customer1` FOREIGN KEY (`Customer_idCustomer`) REFERENCES `Customer` (`idCustomer`) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `fk_Customer_has_Employees_Employees1` FOREIGN KEY (`Employees_idEmployees`) REFERENCES `Employees` (`idEmployees`) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Import data
--
SET FOREIGN_KEY_CHECKS=1;
INSERT INTO StoreLocation (store_name) VALUES
('Uptown Market'),
('Downtown Deli'),
('Sunny Side Store'),
('The Corner Shop');

INSERT INTO StoreAddress (address, idStoreLocation) VALUES
('123 Main St', 1),
('456 Market St', 2),
('789 Sunshine Ave', 3),
('111 Side St', 4);

INSERT INTO StoreEmail (email, idStoreLocation) VALUES
('uptownmarket@email.com', 1),
('downtowndeli@email.com', 2),
('sunnysidestore@email.com', 3),
('thecornershop@email.com', 4);

INSERT INTO StorePhone (phone, idStoreLocation) VALUES
('555-555-1212', 1),
('555-555-1313', 2),
('555-555-1414', 3),
('555-555-1515', 4);


INSERT INTO Customer (name, address) VALUES
('Alice Smith', '123 Main St., Anytown USA'),
('Bob Johnson', '456 Elm St., Anytown USA'),
('Charlie Davis', '789 Oak St., Anytown USA'),
('Dave Baker', '246 Maple St., Anytown USA'),
('Emily Lee', '369 Pine St., Anytown USA'),
('Frank Kim', '951 Cedar St., Anytown USA'),
('Grace Chen', '753 Spruce St., Anytown USA');

INSERT INTO CustomerPhone (phone, Customer_idCustomer) VALUES
('555-555-1234', 1),
('555-555-5678', 2),
('555-555-9012', 3),
('555-555-3456', 4),
('555-555-7890', 5),
('555-555-2468', 6),
('555-555-1357', 7);

INSERT INTO CustomerEmail (email, Customer_idCustomer) VALUES
('alice.smith@example.com',1),
('bob.johnson@example.com',2),
('charlie.davis@example.com',3),
('dave.baker@example.com',4),
('emily.lee@example.com',5),
('frank.kim@example.com',6),
('grace.chen@example.com',7);


INSERT INTO Employees (name, position, salary, StoreLocation_idStoreLocation)
VALUES
  ('Emma Green','Manager', 75000, 1),
  ('Liam Brown','Assistant Manager', 65000, 1),
  ('Ava Johnson','Sales Associate', 50000, 2),
  ('Oliver Tree','Sales Associate', 50000, 3),
  ('Lewis Hamilton','Technician', 55000, 4),
  ('Lando Norris','Technician', 55000, 1),
  ('Sebastian Vettle','Receptionist', 40000, 4),
  ('Valtori Bottas','Receptionist', 40000, 2);

INSERT INTO EmployeesEmail (email, employees_idEmployees)
VALUES
  ('manager1@gmail.com', 1),
  ('assistantmanager1@gmail.com', 2),
  ('salesassociate1@gmail.com', 3),
  ('salesassociate2@gmail.com', 4),
  ('technician1@gmail.com', 5),
  ('technician2@gmail.com', 6),
  ('receptionist1@gmail.com', 7),
  ('receptionist2@gmail.com', 8);

INSERT INTO EmployeesPhone (phone, employees_idEmployees)
VALUES
  ('555-555-1212', 1),
  ('555-555-1213', 2),
  ('555-555-1214', 3),
  ('555-555-1215', 4),
  ('555-555-1216', 5),
  ('555-555-1217', 6),
  ('555-555-1218', 7),
  ('555-555-1219', 8);

INSERT INTO EmployeesAddress (address, employees_idEmployees)
VALUES
  ('1234 Main St', 1),
  ('5678 Main St', 2),
  ('1234 Elm St', 3),
  ('5678 Elm St', 4),
  ('1234 Oak St', 5),
  ('5678 Oak St', 6),
  ('1234 Maple St', 7),
  ('5678 Maple St', 8);


INSERT INTO Equipment (maiteneance, availability, manufacturer, rental_cost, description, StoreLocation_idStoreLocation) VALUES
(0, 1, 'Acme Corp', 19.99, 'Power Drill', 1),
(1, 0, 'Gizmo Industries', 12.99, 'Chainsaw', 2),
(0, 1, 'Widget Co', 9.99, 'Hammer', 3),
(1, 0, 'Sprocket Enterprises', 24.99, 'Circular Saw', 4);

INSERT INTO SerialNum (serial_num, equipment_idequipment) VALUES
(12345, 1),
(67890, 2),
(24680, 3),
(13579, 4);



INSERT INTO RentalAgreement (price,payment_type, insurance_cost, start_date, end_date, Customer_idCustomer, Equipment_idEquipment) VALUES 
(200.00, 'Credit Card', '20.00', '2023-02-15', '2023-02-20', 1, 1),
(350.00, 'Cash', '30.00', '2023-02-14', '2023-02-20', 2, 2),
(450.00, 'PayPal', '50.00', '2023-02-16', '2023-02-21', 3, 3),
(300.00, 'Credit Card', '40.00', '2023-02-17', '2023-02-23', 4, 4),
(400.00, 'Cash', '60.00', '2023-02-18', '2023-02-25', 5, 3),
(250.00, 'Credit Card', '25.00', '2023-02-15', '2023-02-19', 6, 2),
(500.00, 'Check', '70.00', '2023-02-15', '2023-02-22', 7, 1);


INSERT INTO CreatesRentalAgreement (Customer_idCustomer, Employees_idEmployees) VALUES
(1,2),
(3,4),
(4,5),
(6,2),
(3,1),
(2,7),
(7,3);



INSERT INTO Invoice (Customer_idCustomer, Employees_idEmployees, Equipment_idEquipment, StoreLocation_idStoreLocation) VALUES
(1, 3, 1, 1),
(2, 4, 3, 2),
(3, 5, 2, 4),
(4, 2, 2, 3),
(5, 1, 1, 2),
(6, 6, 4, 4),
(7, 7, 4, 1);

INSERT INTO InvoiceRental (RentalAgreement_idRentalAgreement, Invoice_idInvoice) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7);

INSERT INTO ProvidesInvoice (Customer_idCustomer, Employees_idEmployees) VALUES
(2,4),
(3,3),
(5,7),
(7,1),
(3,5),
(2,6),
(2,2);

INSERT INTO Maintains(Equipment_idEquipment, Employees_idEmployees) VALUES
(1,5),
(3,5),
(2,6),
(4,6);

INSERT INTO Rents(RentalAgreement_idRentalAgreement, Customer_idCustomer) VALUES
(5,1),
(6,3),
(6,4),
(3,5);

--
-- Views
--
DROP VIEW IF EXISTS rental_agreement_per_Employees;
CREATE VIEW rental_agreement_per_Employees(Employees_name, num_rental_agreements) AS 
(
	SELECT 	Employees.name, 
			COUNT(*) '# of rental agreements made'
	FROM Customer
	JOIN CreatesRentalAgreement ON Customer.idCustomer = CreatesRentalAgreement.Customer_idCustomer
	JOIN Employees ON Employees.idEmployees = CreatesRentalAgreement.Employees_idEmployees
	GROUP BY Employees.name);

DROP VIEW IF EXISTS rental_agreement_per_Employees;
CREATE VIEW rental_agreement_per_Employees(Employees_name, num_rental_agreements) AS 
(
	SELECT 	name, 
			AVG(DATEDIFF(end_date,start_date)) 'Avg. Rental Period'
	FROM Customer
	JOIN Rents ON Customer.idCustomer = Rents.Customer_idCustomer
	JOIN RentalAgreement ON RentalAgreement.idRentalAgreement = Rents.RentalAgreement_idRentalAgreement
	GROUP BY Customer.name);

DROP VIEW IF EXISTS Employees_that_do_not_rent;
CREATE VIEW Employees_that_do_not_rent (Employees_name) AS
(
SELECT DISTINCT(name)
FROM Employees 
WHERE idEmployees NOT IN 
	(SELECT Employees_idEmployees
	 FROM ProvidesInvoice));
     


